export SOCFAMILY=g12a
